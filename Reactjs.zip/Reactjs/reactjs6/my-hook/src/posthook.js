import React,{useState} from "react";
import Comment from "./commenthook";
import copy from "copy-to-clipboard";
//import Comment_Hk from "./commenthook"
function Post_HK(props){
    const [post, setPost] = useState("");
    const [postList, setpostList] = useState([]);
    
  function handleSubmit(e) {
    e.preventDefault();
    if (post.length === 0) {
      return;
    }
    setpostList(postList.concat(post))
    setPost("")
  }
  function handleChange(e)
  {
    setPost(e.target.value)
  }

  const copytoclipboard = (val) => {
    copy(val);
    alert(`You have copied ${val}`);
 }

    return(
      <div>
          
      <form  onSubmit={handleSubmit}>
      <textarea onChange={handleChange} value={post}></textarea>  
      <button>Post</button>
      </form>
      { postList.map(item => (
       <>
       <h1 key={item}>{item}<button onClick={()=>copytoclipboard(item)}>copy</button></h1>
       <Comment/>
       </>
     ))}
      
            
       
       </div>
    )
}


export default Post_HK;