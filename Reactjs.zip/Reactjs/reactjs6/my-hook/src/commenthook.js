import React,{useState} from "react";
import copy from "copy-to-clipboard";
function Comment(props){
    const [comments, setcomment] = useState("");
    const [commentsList, setcommentList] = useState([]);
    function handleChange(e)
    {
      setcomment(e.target.value)
    }
  
    function handleSubmit(e) {
      e.preventDefault();
      if (comments.length === 0) {
        return;
      }
      setcommentList(commentsList.concat(comments))
      setcomment("")
   
    }
    const copytoclipboard = (val) => {
      copy(val);
      alert(`You have copied ${val}`);
   }
  
    return(
        <div>
        { commentsList.map(item => (
      <>
      <p key={item.id} >{item}<button onClick={()=>copytoclipboard(item)}>copy</button></p>
      </>
    ))}
       <form onSubmit={handleSubmit}>
          <input onChange={handleChange} value={comments}/>
          <button>Comment</button>
         </form>
       </div>
    )
}

export default Comment;