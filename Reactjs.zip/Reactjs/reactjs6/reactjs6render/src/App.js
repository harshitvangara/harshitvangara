import Post from './postrender';
import './App.css';
import Copyrender from './copyrender';

function App() {
  return (
    <div className="App">
     <Copyrender render={(handleChange,handleSubmit,items,text,copytoclipboard)=> <Post handleChange={handleChange} handleSubmit={handleSubmit} items={items} text={text} copytoclipboard={copytoclipboard}/>}/>
   
    </div>
  );
}

export default App;
