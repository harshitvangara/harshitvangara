import React from 'react'
import copy from "copy-to-clipboard";  
 class Copyrender extends React.Component {
    constructor(props) {
        super(props);
        this.state = {text:'' ,items:[]};
        this.handleChange=this.handleChange.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
       
      }
     copytoclipboard=(val)=>{
       copy(val);
         alert(`You have copied ${val} .`);
     }
      handleChange=(e)=> {
        this.setState({ text: e.target.value });
      }
    
      handleSubmit=(e)=> {
        e.preventDefault();
       
        const newItem = {
          text: this.state.text,
          id: Date.now()
        };
        this.setState(state => ({
          items: state.items.concat(newItem),
          text: ''
        }));}
  render() {
    return (
      <>
    {this.props.render(this.handleChange,this.handleSubmit,this.state.items,this.state.text,this.copytoclipboard)}
      </>
    )
  }
}

export default Copyrender