import React from 'react'

class Comment extends React.Component {
   
  render() {
    const {handleChange,handleSubmit,items,text,copytoclipboard}=this.props
    return (
        <div>
        <List items={items} copytoclipboard={copytoclipboard}/>
        <form onSubmit={handleSubmit}>
          <input onChange={handleChange} value={text}/>
          <button>Comment</button>
         </form>
      </div>
    )
  }
}

class List extends React.Component {
    render() {
      
      return (
      
          this.props.items.map(item => (
            <>
            <p key={item.id} >{item.text}<button onClick={()=>this.props.copytoclipboard(item.text)}>copy</button></p>
            </>
          ))
      
      );
    }
  }

export default Comment