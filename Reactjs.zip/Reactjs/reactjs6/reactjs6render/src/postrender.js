import React from 'react'
import Comment from './comntrendr';
import Copyrender from './copyrender';
class Post extends React.Component{  
   
render(){
    const {handleChange,handleSubmit,items,text,copytoclipboard}=this.props
    return(
      <>
      <form  onSubmit={handleSubmit}>
      <textarea onChange={handleChange} value={text}></textarea>  
      <button>Post</button>
      </form>
      <List items={items} copytoclipboard={copytoclipboard}/>
      
      </>
    )
}
}
class List extends React.Component {
    render() {
      return (
            this.props.items.map(item => (
            <>
            <h1 key={item.id}>{item.text}<button onClick={()=>this.props.copytoclipboard(item.text)}>copy</button></h1>
            <Copyrender render={(handleChange,handleSubmit,items,text,copytoclipboard)=> <Comment handleChange={handleChange} handleSubmit={handleSubmit} items={items} text={text} copytoclipboard={copytoclipboard}/>}/>
   
            </>
          ))
      
      );
    }
  }

export default Post