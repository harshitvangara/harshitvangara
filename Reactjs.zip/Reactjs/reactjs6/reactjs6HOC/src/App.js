import './App.css';
import Post from './post';

function App() {
  return (
    <>
   <Post/>
   </>
  );
}

export default App;
