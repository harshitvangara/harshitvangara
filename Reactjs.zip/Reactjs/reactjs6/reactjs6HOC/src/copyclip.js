import React from "react"
import copy from "copy-to-clipboard";
const NewComponent=(OriginalComponent) =>{
    class NewComponent extends React.Component{
        constructor(props) {
            super(props);
            this.state = {text:'' ,items:[]};
            this.handleChange=this.handleChange.bind(this);
            this.handleSubmit=this.handleSubmit.bind(this);
           
          }
          copytoclipboard=(val)=>{
            copy(val);
            alert(`You have copied ${val} .`);
        }
          handleChange(e) {
            this.setState({ text: e.target.value });
          }
        
          handleSubmit(e) {
            e.preventDefault();
           
            const newItem = {
              text: this.state.text,
              id: Date.now()
            };
            this.setState(state => ({
              items: state.items.concat(newItem),
              text: ''
            }));}
            
          
            
          
        render(){
            return <OriginalComponent copytoclipboard={this.copytoclipboard} items={this.state.items}text={this.state.text} handleChange={this.handleChange} handleSubmit={this.handleSubmit}/>
          }
    }
 return NewComponent
}

export default NewComponent


