import React from 'react';
import './App.css';

class Counter extends React.Component{
  constructor(props) {
    super(props);
    this.state = {counter:0};
    this.incrementCounter=this.incrementCounter.bind(this)
    this.decrementCounter=this.decrementCounter.bind(this)
  }

  incrementCounter(){
    this.setState({counter:this.state.counter-1})
  }
  decrementCounter(){
    this.setState({counter:this.state.counter+1})
  }

  render(){
    return(
      <center>
      <h1>Counter : {this.state.counter}</h1>
      <button onClick={this.incrementCounter}>Decrease</button>
      <button onClick={this.decrementCounter}>Increase</button>
      </center>
    )
  }
}

export default Counter