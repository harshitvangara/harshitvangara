import Category from './App1';
import './App.css';
import Skill from './App2'
function App() {
   var main=[{category:"technical skill",skill:["skill1","skill2","skill3","skill4"]},{category:"management skill",skill:["skill1","skill2","skill3","skill4"]}]
   var arr=[];
   for(var i=0;i<main.length;i++){
     arr.push(<Category c2={main[i].category}/>)
     for(var j=0;j<main[i].skill.length;j++){
      arr.push(<Skill c1={main[i].skill[j]}/>)
     }
   }
   
  return (
    <div className="App">
       <h1>Welcome to my page</h1>
      {arr}

    </div>
  );
}




export default App;
