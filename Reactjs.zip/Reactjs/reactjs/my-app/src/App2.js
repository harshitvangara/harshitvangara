import React from 'react';

class Skill extends React.Component{
    render(){
        return <h3>{this.props.c1}</h3>
    }
}

export default Skill