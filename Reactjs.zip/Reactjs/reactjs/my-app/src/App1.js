import React from 'react';

class Category extends React.Component{
    render(){
    return <h2>{this.props.c2}</h2>
    }
}



export default Category