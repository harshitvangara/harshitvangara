import { createSlice } from '@reduxjs/toolkit';


export const AppointmentSlice = createSlice({

  name: 'Appointment',
  initialState:{
    UserAppointmentlist: [
        { "pname": "Vishnu", "gender": "Male", "age": 26, "pno": "9605027644", "date": "10-10-1998", "time": "06:00 PM", "dname": "Dr.Ananth", "cr": "Consult" },
  
    ],
  },
  reducers: {
    add: (state, action) => {
     // console.log("..inside");
      state.UserAppointmentlist.push(action.payload.user);
    },
    delete: (state, action) => {
      // state.UserAppointmentlist = 
      // state.UserAppointmentlist.splice(action.payload.id,1)
      var patients=state.UserAppointmentlist
      for(let i=0; i<patients.length;i++){
        if(action.payload.id===patients[i].pname){
          patients.splice(i,1);
          //console.log(state.UserAppointmentlist);
          break;
        }
      }
      state.UserAppointmentlist=patients;
    },
    update: (state, action) => {
     // console.log("user id",action.payload.user.id);
      // state.UserAppointmentlist[action.payload.user.id] = 
      //               action.payload.user;
      var patients=state.UserAppointmentlist
      for(let i=0; i<patients.length;i++){
        if(action.payload.id===patients[i].pname){
          patients.splice(i,1);
          //console.log(state.UserAppointmentlist);
          break;
        }
      }

    }

  }});  

export default AppointmentSlice.reducer

