import React from 'react'
import './App.css'

 class Invest extends React.Component{
     constructor(props){
         super(props)
           
             this.invest=this.invest.bind(this)
             
        }
             invest= (e) => {
                 this.props.onChange(e.target.value);

             }
       
           render(){
               return(
                <input name="mnthsavings" class="inpt inputBox numbersOnly loanAmt" id="loan_amountInv" type="text" value={this.props.value}
                onChange={this.invest} />
                
               )
 }
 }
  export default Invest