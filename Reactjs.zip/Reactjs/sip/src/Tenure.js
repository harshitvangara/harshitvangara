import React from 'react'
import './App.css'

 class Tenure extends React.Component{
     constructor(props){
         super(props)
           
             this.tenoure=this.tenoure.bind(this)
             
        }
             tenoure= (e) => {
                 this.props.onChange(e.target.value);

             }
       
           render(){
               return(
                <input name="mnthsavings" class="inputBox inpt numbersOnly" id="tenure" type="text" value={this.props.value}
                onChange={this.tenoure} />
                
               )
 }
 }
  export default Tenure