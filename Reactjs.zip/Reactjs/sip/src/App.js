import './App.css';
import React from 'react';
import Invest from './Invest';
import Tenure from './Tenure';

class Calculator extends React.Component {
    constructor(props){
        super(props)
            this.state={
                invest:"",
                tenoure:"",
                interest:""
            }
           
            this.onInvest=this.onInvest.bind(this)
            this.Tenure=this.Tenure.bind(this)
            this.interest=this.interest.bind(this)
       }
        onInvest= (e) => {
                this.setState({invest:e});
            }
         Tenure =(e)=>{
             this.setState({tenoure:e});

         }
          interest=(e)=>{
              this.setState({interest:e.target.value});
          }

  render() {
    return (
        <div class="col-md-12">
        <h1 class="sipCalcHeading">SIP Calculator - Calculate SIP Returns &amp; Invest in SIP</h1>
        
        
        <div class="row">
            <div class="col-md-12 col-xs-12 calcSection">
                <div class="loanCalc">
                    <div class="col-md-7 col-lg-8 col-xs-12 sipClcForm">
                        <div class="inpt-slider">
                            <div class="radioBtn">
                                <input name="radioGroup" id="sipInvest" type="radio" checked="checked"/> 							
                                <label class="flRight" for="sipInvest">I Want to Invest</label> 
                                <input name="radioGroup" id="sipGoal" type="radio"/> 
                                <label for="sipGoal">I Know My Goal</label>
                            </div>
                        </div>
                        <div class="ionSlider newCalc">
                            <div class="inpt-slider canInvest">
                                <div class="inpt-statement loan_amount">
                                <label class="canInvest" for="loan_amountInv">I wish to invest per month</label> 						
                                
                          <Invest value={this.state.invest} onChange={this.onInvest}/>
                                </div>
                            </div>
                            <div class="inpt-slider">
                                <div class="inpt-statement tenure"><label for="tenure">No. of years</label> 				
                                			
                         <Tenure value={this.state.tenoure} onChange={this.Tenure}/>
                                </div>
        
                            </div>
                            <div class="inpt-slider">
                                <div class="inpt-statement interest_rate">
                                <label for="interest_rate">Expected Rate of Return </label> 
                                <input name="mnthsavings" class="inputBox inpt numbersDecimal" id="interest_rate" type="text" value={this.state.interest}
                       onChange={this.interest}/>

                                </div>
        
                            </div>
        </div>
        </div>
        <div class="col-md-5 col-xs-12 totalBox">
        <div class="finalResult">
        
        <div class="resRow sipInv"><span>Invested Amount</span> <strong class="rupeeIconSip">₹</strong>{this.state.invest*this.state.tenoure*12}</div>
        <div class="resRow sipInv"><span>Resultant Amount</span> <strong class="rupeeIconSip">₹</strong>{(this.state.invest*[(Math.pow(1 + (this.state.interest/1200),( this.state.tenoure*12))-1) / (this.state.interest/1200)]*(1+(this.state.interest/1200)))}</div>
        <a class="btn btn-default panel-orange-btn sipStartASip" href="#" rel="nofollow">Start a SIP</a></div>
        </div>
        </div>
        </div>
        </div>
        </div>
    
     
    )
  }  
  }
export default Calculator;