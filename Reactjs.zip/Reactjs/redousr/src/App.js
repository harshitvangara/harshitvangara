import React from 'react'
import './App.css';


class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      items: []
    };
  }

  componentDidMount() {
    fetch("http://localhost:8080/user")
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            isLoaded: true,
            items: result
          });
        },
        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error) => {
          this.setState({
            isLoaded: true,
            error
          });
        }
      )
  }
  


 presence(){
    
  var x=document.getElementById("text1").value;
  var y=document.getElementById("text2").value;
  
  var xhttp = new XMLHttpRequest();
  xhttp.open("PUT", "http://localhost:8080/presence/user"+x, true);
  xhttp.setRequestHeader("Content-Type", "application/json");
  xhttp.send(JSON.stringify({"press":y}));
  this.componentDidMount();
}

 status(){
  var x1=document.getElementById("text3").value;
  var y1=document.getElementById("text4").value;    
  var xhttp = new XMLHttpRequest();
  xhttp.open("PUT", "http://localhost:8080/user"+x1, true);
  xhttp.setRequestHeader("Content-Type", "application/json");
  xhttp.send(JSON.stringify({"stat":y1}));
  this.componentDidMount();
}

 newuser(){
  
  var name1 =document.getElementById("text5").value;
  var presence=document.getElementById("text71").value;
  var userID=document.getElementById("text7").value;
  var statusMessage=document.getElementById("text6").value;
  var profilePicture=document.getElementById("text8").value;

 
  var xhttp = new XMLHttpRequest();
  xhttp.open("POST", "http://localhost:8080/user", true);
  xhttp.setRequestHeader("Content-Type", "application/json");
  xhttp.send(JSON.stringify({"id": parseInt(userID),
  "userID":"USR0000"+userID,
  "name":name1,
  "profilePicture":profilePicture,
  "statusMessage":statusMessage,
  "presence":parseInt(presence)}));
  this.componentDidMount();
}

 dltusr(){
  var del = document.getElementById("text9").value;
  var xhttp = new XMLHttpRequest();
  xhttp.open("DELETE", "http://localhost:8080/user"+del, true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send();
  this.componentDidMount();
}

  render() {

    const { error, isLoaded, items } = this.state;
    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      
      return (
        <div>
        
          {items.map(item => (
            <div>
              <div className='name'>{item.name}
              </div>
              
              <div><img src={item.profilePicture} alt="img"className={'lorem' +item.presence}></img>
              </div>
              <div className='msg'>{item.statusMessage}
              </div>
            </div>

          )
        ) }
<button type="button" className="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal2">Add user</button>
<div id="myModal2" className="modal fade" role="dialog">
  <div className="modal-dialog">    
    <div className="modal-content">
      <div className="modal-header">
        <button type="button" className="close" data-dismiss="modal">&times;</button>
        <h4 className="modal-title">Add user</h4>
      </div>
      <div className="modal-body">
        <form>
            <input type="text" placeholder="name" id="text5"/>
            <input type="text" placeholder="statusmessage" id="text6"/>
            <input type="number" placeholder="Presence" id="text71"/>
            <input type="number" placeholder='UserID' id='text7'/>
            <input type="text" placeholder="image.jpg" id="text8"/>
        </form>
      </div>
      <div className="modal-footer">
        <button type="button" className="btn btn-default" data-dismiss="modal" onClick={this.newuser}value="submit">Submit</button>
        <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal3">Delete user</button>
<div id="myModal3" class="modal fade" role="dialog">
  <div class="modal-dialog">    
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Delete user</h4>
      </div>
      <div class="modal-body">
        <form>
            
            <input type="number" placeholder="USERID" id="text9"/>
            
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onClick={this.dltusr} value="submit">Submit</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal1">Status change</button>
<div id="myModal1" class="modal fade" role="dialog">
  <div class="modal-dialog">    
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Update Status</h4>
      </div>
      <div class="modal-body">
        <form>
            <input type="number" placeholder="USERID" id="text3"/>
            <input type="text" placeholder="statusmessage" id="text4"/>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onClick={this.status} value="submit">Submit</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Update Presence</button>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">    
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Update Presence</h4>
      </div>
      <div class="modal-body">
        <form >
            <input type="number" placeholder="USERID" id="text1"/>
            <input type="number" placeholder="Presence" id="text2"/>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onClick={this.presence} value="submit">Submit</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
</div>

      );
    }
  }
}

export default App;
