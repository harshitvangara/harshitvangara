import React from "react";
class Input extends React.Component{
    InputValueChange=(e)=>{
        this.props.onInputValueChange(e.target.value)
    }
    render(){
        return(
            <div className="form-group">
            <input type="text" className="form-control" placeholder={this.props.placeholder} value={this.props.value} onChange={this.InputValueChange}/>
        </div>
        
        );
    }
}
export default Input