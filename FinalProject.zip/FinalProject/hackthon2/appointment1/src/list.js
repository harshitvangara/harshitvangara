import React from "react"


class List extends  React.Component {

    handleDelete=(e)=>{
        this.props.Delete(e)
    }
    handleEdit=(e)=>{
        this.props.Edit(e)
    }
  render() {
    return (
      <div>
         
        <section className="main-content">
<div className="container">
    <br/>
    <br/>

    <table className="table">
        <thead>
            <tr>
                <th>Patient</th>
                <th>Status</th>
                <th>Appointment</th>
                <th>Phone</th>
                <th>Doctor</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        {this.props.Lists.map(list=>(
            <tr>
                <td>
                    <div className="user-info">
                        <div className="user-info__img">
                            <img src="img/prof.png" alt="User Img"/>
                        </div>
                        <div className="user-info__basic">
                            <h5 className="mb-0">{list.Patient_Name}</h5>
                            <p className="text-muted mb-0">{list.Age}, {list.Male_Female}</p>
                        </div>
                    </div>
                </td>
                <td>
                    <span className="btn btn-success">{list.Consule_Revisit}</span>
                </td>
                <td>
                    <h6 className="mb-0">{list.Time}</h6>
                    <small>{list.Date}</small>
                </td>
                <td>
                    <h6 className="mb-0">{list.Phone_Number}</h6>
                    <a href="#!"><small>Contact</small></a>
                </td>
                <td>
                    <h6 className="mb-0">{list.Doctor_Name}</h6>
                </td>
                <td>
                    <button onClick={()=>this.handleEdit(list.Patient_Name)}>Edit</button>
                    <button onClick={()=>this.handleDelete(list.Patient_Name)}>Delet</button>
                </td>
            </tr>
        ))}
            
        </tbody>
    </table>
</div>
</section>
      </div>
    );
  }
}

export default List;
