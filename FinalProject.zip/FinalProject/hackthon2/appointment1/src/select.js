import React from "react";
class Select extends React.Component{
    SelectChange=(e)=>{
        this.props.onSelectChange(e.target.value)
    }
    render(){
        return(
            <div class="form-group">
            <select  class="form-control"  value={this.props.value} onChange={this.SelectChange}>
            <option name1={this.props.name}>{this.props.one}</option>
            <option name2={this.props.name}>{this.props.two}</option> 
            </select>                               
            </div>
        );
    }
}
export default Select