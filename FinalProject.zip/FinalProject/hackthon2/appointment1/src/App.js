import React from 'react';
import List from './list';
import Select from './select';
import Input from './input';
import axios from 'axios';
class Appointment extends React.Component {
	constructor(props){
		super(props);
		this.state={
			Patient_Name:"",
			Male_Female:"",
			Age:"",
			Phone_Number:"",
			Date:"",
			Time:"",
			Doctor_Name:"",
			Consule_Revisit:"",
			PatientList:[]
		}
	}

	PatientNameChange=(e)=>{
		this.setState({
			Patient_Name:e
		})
	}
	MaleFemaleChange=(e)=>{
		this.setState({
			Male_Female:e
		})
	}
	AgeChange=(e)=>{
		this.setState({
			Age:e
		})
	}
    PhoneNumberChange=(e)=>{
		this.setState({
			Phone_Number:e
		})
	}
    DateChange=(e)=>{
		this.setState({
			Date:e
		})
	}
    TimeChange=(e)=>{
		this.setState({
			Time:e
		})
	}
    DoctorNameChange=(e)=>{
		this.setState({
			Doctor_Name:e
		})
	}
    ConsuleRevisitChange=(e)=>{
		this.setState({
			Consule_Revisit:e
		})
	}
	handleSubmit=(e)=>{

		if(this.state.Patient_Name===null||this.state.Patient_Name===""){
			alert("Patient Name must be filled.");
			return ;
		}
		else if(!/^[A-Za-z.\s]+$/.test(this.state.Patient_Name)){
			alert("Patient Name must be in Alphabets only.");
			return ;
		}
		if(this.state.Age===null||this.state.Age===""){
			alert("Age must be filled.");
			return ;
		}
		else if(isNaN(this.state.Age)||this.state.Age<1||this.state.Age>100){
			alert("Age must be between 1 to 100");
			return ;
		}
		if(this.state.Phone_Number===null||this.state.Phone_Number===""){
			alert("Phone Number must be filled.");
			return ;
		}
		else if(isNaN(this.state.Phone_Number)||this.state.Phone_Number.length!==10){
			alert("Phone Number must be in 10 digits only.");
			return ;
		}
		if(this.state.Date===null||this.state.Date===""){
			alert("Date must be filled.");
			return ;
		}
		else if(!/^([0-9]{2})-([A-Za-z]{3})-([0-9]{4})$/.test(this.state.Date)){
			alert("Date must be type in 01-Jan-2022 this patren only.");
			return ;
		}
		if(this.state.Time===null||this.state.Time===""){
			alert("Time must be filled.");
			return ;
		}
		else if(!/^([0-1]?[0-9]|2[0-3]):([0-5][0-9])?$/.test(this.state.Time)){
			alert("Time must be between 00:00 to 23:59 only.");
			return ;
		}
		if(this.state.Doctor_Name===null||this.state.Doctor_Name===""){
			alert("Doctor Name must be filled.");
			return ;
		}
		else if(!/^[A-Za-z.\s]+$/.test(this.state.Doctor_Name)){
			alert("Doctor Name must be in Alphabets only.");
			return ;
		}
		
		this.setState({
			PatientList: [...this.state.PatientList, 
				{
					"Patient_Name" : this.state.Patient_Name , 
					"Male_Female" : this.state.Male_Female , 
					"Age" : this.state.Age , 
					"Phone_Number" : this.state.Phone_Number , 
					"Date" : this.state.Date , 
					"Time" : this.state.Time , 
					"Doctor_Name" : this.state.Doctor_Name , 
					"Consule_Revisit" : this.state.Consule_Revisit
				}],
				Patient_Name:"",
				Male_Female:"",
				Age:"",
				Phone_Number:"",
				Date:"",
				Time:"",
				Doctor_Name:"",
				Consule_Revisit:""
				
		});
		
	 
		// e.preventDefault()
		axios
        .post(
            "http://localhost:8000/storedata",
            ( this.state)
        )
        .then((res) => console.log("success", res))
        .catch((err) => {
            console.log(err.response);
        });
	}

	Delet_PatientDetails=(e)=>{
		var name=this.state.PatientList
		  for(var i=0;i<name.length;i++){
			  if(name[i]["Patient_Name"]===e){
				  name.splice(i,1)
			  }
		  }
		  this.setState({PatientList:name})
	  }

  Edit_PatientDetails=(e)=>{
	var names=this.state.PatientList
	for(var i=0;i<names.length;i++){
	  if(names[i]["Patient_Name"]===e){
		  this.setState({"Patient_Name":names[i].Patient_Name,"Male_Female":names[i].Male_Female,"Age":names[i].Age,"Phone_Number":names[i].Phone_Number,"Date":names[i].Date,"Time":names[i].Time,"Doctor_Name":names[i].Doctor_Name,"Consule_Revisit":names[i].Consule_Revisit})
		  names.splice(i,1)
		  break;
	  }
	}
}



  render() {
	  
    return (
      <div>
        <section className="form-content">
          	<div className="container register-form">
            	<div className="form">
                	<div className="note">
                    	<p>Welcome to Gradious Doctor Appointment Booking</p>
                	</div>
					      <div className="form-content">
                    	  <div className="row">
                       	<div className="col-md-4">
							<Input value={this.state.Patient_Name} placeholder='Patient Name *' onInputValueChange={this.PatientNameChange}/>
							<Select value={this.state.Male_Female} onSelectChange={this.MaleFemaleChange}  one="Male" two="Female" name="M"/>
							<Input value={this.state.Age} placeholder='Age *' onInputValueChange={this.AgeChange}/>
                        </div>
                      <div className="col-md-4">
						    <Input value={this.state.Phone_Number} placeholder='Phone Number *' onInputValueChange={this.PhoneNumberChange}/>
                        	<Input value={this.state.Date} placeholder="DD-MMM-YYYY *" onInputValueChange={this.DateChange}/>
                        	<Input value={this.state.Time} placeholder="Time *" onInputValueChange={this.TimeChange}/>
	                    </div>
                      <div className="col-md-4">
						    <Input value={this.state.Doctor_Name} placeholder="Doctor Name *" onInputValueChange={this.DoctorNameChange}/>
							<Select value={this.state.Consule_Revisit} onSelectChange={this.ConsuleRevisitChange} one="Consult" two="Revisit" name="C"/>
                        	</div>
                    	</div>
                    	<button type="button" className="btnSubmit" onClick={this.handleSubmit}>Book Appointment</button>
					</div>
           		 </div>
        	</div>
		</section>
		<List Lists={this.state.PatientList} Delete={this.Delet_PatientDetails} Edit={this.Edit_PatientDetails}/> 
      </div>
    );
  }
}



export default Appointment;