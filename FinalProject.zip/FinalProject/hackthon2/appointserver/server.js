var mysql = require('mysql');
const express=require('express');
const cors=require('cors')
const bodyparser=require('body-parser')
const app=express()
app.use(bodyparser.urlencoded({extended:true}))
app.use(bodyparser.json());
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "testdb"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Database Connected");
});

app.use(cors());
app.post("/storedata",(req,res)=>{
    let data=req.body;

    console.log(data)
    sql=`INSERT INTO appointment (patient_name,phonenumber,doctorname,gender,date,appoint,age,time) VALUES ('${data.Patient_Name}','${data.Phone_Number}','${data.Doctor_Name}','${data.Male_Female}','${data.Date}','${data.Consule_Revisit}','${data.Age}','${data.Time}')`;
    con.query(sql,(err,results)=>{
      if(err) throw err;
       res.send(JSON.stringify({"status":200,"error":null,"response":results}));
     });

});


app.listen(port=8000, (err) => {
    if (err) throw err;
    console.log(`App listening on port ${port}!`)
  });