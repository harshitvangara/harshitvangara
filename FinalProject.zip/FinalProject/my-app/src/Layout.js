import { Outlet, Link } from "react-router-dom";
import Login from "./LogIn";
const Layout = () => {
  return (
    <>
      <nav>
        
          
          
            <Link to="/login"></Link>
        
        
      </nav>

      <Outlet />
    </>
  )
};

export default Layout;