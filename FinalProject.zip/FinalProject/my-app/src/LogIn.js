import React from "react";
import { Outlet, Link } from "react-router-dom";
import './App.css';

function Login() {
 
  return (
    <>
 
  <div className="App">
  <h3>Login Successfull</h3>
  </div>
 
    </>
  );
}

export default Login;
