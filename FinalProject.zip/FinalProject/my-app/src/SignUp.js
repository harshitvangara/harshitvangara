import React, {  useState } from "react"

import './App.css';

function SignUp() {
 // const[array,setArray]=useState([])
  const emailRegex = /\S+@\S+\.\S+/;
  const phoneRegex = /^[6-9]\d{9}$/gi;
  const [errorMessages, setErrorMessages] = useState({});
  const [username,setName]=useState('')
  const [password,setPassword]=useState('')
  const [mail,setMail]=useState('')
  const [mobile,setMobile]=useState('')
  const [date,setDate]=useState('')
  const [password2,setPassword2]=useState('')
  // useEffect(()=>{
  //   localStorage.setItem("userInfo",JSON.stringify(array))
  // },array)
  const passwordhandle=(event)=>{
    setPassword2(event.target.value)

  }
  const namehandle=(event)=>{
  setName(event.target.value)
  }
  const passhandle=(event)=>{
    setPassword(event.target.value)
   }
  const emailhandle=(event)=>{
 setMail(event.target.value)
 
  }
  const mobilehandle=(event)=>{
 setMobile(event.target.value)
  }
  const datehandle=(event)=>{
    setDate(event.target.value)
  }
  const resethandle=()=>{
    setName("")
    setMail("")
    setMobile("")
    setPassword("")
    setDate("")
    setPassword2("")
  }
   const errors = {
    name: "Name Should be in Alphabets",
    pass: "Minimum 8 characters ,at least one number",
    email:"Email should be valid",
    number:"number should be 10 digits" ,
    date:"Date must be type in 01-Jan-2022 ",
    pass2:"Passwords doesn't match"
  };
 const handleSubmit = (event) => {
  //Prevent page reload
  event.preventDefault();
 // var arr={}

  var { name, pass ,email,number,dob,pass2} = document.forms[0];
 //console.log(email.value)
  if (!/^[A-Za-z]+$/.test(name.value)) {
    setErrorMessages({ name: "name", message: errors.name });
  }
    else if (!/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/.test(pass.value)) {
    
      setErrorMessages({ name: "pass", message: errors.pass });
    } 
    else if(!emailRegex.test(email.value)){
      console.log(email.value)
      setErrorMessages({ name: "email", message: errors.email });
    }
    else if(!phoneRegex.test(number.value)){
      setErrorMessages({ name: "number", message: errors.number });
    }
    else if (!/^([0-9]{2})-([A-Za-z]{3})-([0-9]{4})$/.test(dob.value)){
      setErrorMessages({ name: "dob", message: errors.date });

    }
    else if(pass.value!==pass2.value){
      setErrorMessages({ name: "pass2", message: errors.pass2 });
    }
    else {
     var storednames=JSON.parse(localStorage.getItem("userinfo"))
     storednames.push({"username":username,"password":password,"email":mail})
     //setArray([...array,{"username":username,"password":password,"email":mail}])
     localStorage.setItem("userinfo",JSON.stringify(storednames))
    
    }
  
  
};


const renderErrorMessage = (name) =>
  name === errorMessages.name && (
    <p className="error">{errorMessages.message}</p>
  );
 
  return (
    <div className="App">
    <form onSubmit={handleSubmit}>
      <input type="text" placeholder="Name" name="name" value={username} onChange={namehandle} required/>
      {renderErrorMessage("name")}
      <input type="text" placeholder="Email" name="email"required value={mail}onChange={emailhandle}/>
      {renderErrorMessage("email")}
      <input type="text" placeholder="Mobile" name="number"required value={mobile}onChange={mobilehandle}/>
      {renderErrorMessage("number")}
      <input type="text" placeholder="Date of Birth" name="dob" value={date}required onChange={datehandle}/>
      {renderErrorMessage("dob")}
      <input type="password" placeholder="Password" name="pass" value={password}onChange={passhandle} required/>
      {renderErrorMessage("pass")}
      <input type="password" placeholder="Confirm Password" name="pass2" value={password2}onChange={passwordhandle}required/>
      {renderErrorMessage("pass2")}
      <div>
      <input type="submit" value="Register" />
      <input type="button" value="Clear" onClick={resethandle}/>
     
      </div>
    </form >
    <p>Already had an account<input type="submit" value="click here"/></p>
    </div>
  );
}

export default SignUp;
