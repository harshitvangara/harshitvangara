import React, { useState } from "react";
import Login from './LogIn'
import SignUp from './SignUp'
//import App from './App'
import "./App.css";
//import {BrowserRouter as Switch,Route,Router,Routes} from 'react-router-dom';
//import {Link} from 'react-router-dom'

//import {BrowserRouter as useHistory} from 'react-router-dom'

function App() {
  //const history=useHistory()
  const [errorMessages, setErrorMessages] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [initial,setInitial]=useState(false);
  
  

  const errors = {
    uname: "Invalid User",
    pass: "Invalid Paasword"
  };

  const handleSubmit = (event) => {
    //Prevent page reload
   event.preventDefault();

    var { uname, pass } = document.forms[0];
   var data= JSON.parse (localStorage.getItem("userinfo"))

   for(var i=0;i<data.length;i++){
    if (data[i].username===uname.value) {
      if (data[i].password===pass.value) {

        setIsSubmitted(true);
       // navigate('/contacts')
       //history.push('/login')
      } 
      else {
        setErrorMessages({ name: "pass", message: errors.pass });
      }
    } else {
      // Username not found
      setErrorMessages({ name: "uname", message: errors.uname });
    }
  }}

  
  const renderErrorMessage = (name) =>
    name === errorMessages.name && (
      <div className="error">{errorMessages.message}</div>
    );

  // JSX code for login form
  const renderForm = (
    <div className="App">
    <div className="form">
      <form onSubmit={handleSubmit}>
          <input type="text" name="uname" placeholder="Name"required />
          {renderErrorMessage("uname")}
          <input type="password" name="pass" placeholder="password" required />
          {renderErrorMessage("pass")}
          <div>
          <button type="submit" value="Login">Login</button>
          <input type="submit"value="Signup" onClick={()=>setInitial(true)}/>
          </div>
      </form>
    </div>
    </div>
  );
if(initial){
  return <SignUp/>
}

else if(isSubmitted){
  return  (
    <Login/>
  )
}
else{
  return (
<>
      {renderForm}   
</>
  );
}
}
export default App;