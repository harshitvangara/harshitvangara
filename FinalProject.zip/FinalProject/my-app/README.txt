Implemeted the Login page and Signup page 
Implemeted login validation and signup validation
Stored the registered candidates in local storage 
Checked the login of the user from items matched in local storage
