import React from "react"
class Orders extends React.Component {
  constructor(props) {
    super(props);
    this.state = { posts: [] };
  }

  componentDidMount() {
    fetch("http://localhost:8000/orders/")
      .then(res => res.json())
      .then((result) => {
        this.setState({ posts: result });
      },
      (error)=>{
        console.log(error);
      })
  }
  
  render() {
   
    return (
      <div>
    

    <table border="1">
        <tr>
            <th>orderNumber</th>
            <th>orderDate</th>
            <th>requiredDate</th>
            <th>shippedDate</th>
            <th>status</th>
            <th>comments</th>
            <th>customersNumber</th>
            
        </tr>
     
       { this.state.posts.map(post=>(
      
        <tr>
            <td>{post.orderNumber}</td>
            <td>{post.orderDate}</td>
            <td>{post.requiredDate}</td>
            <td>{post.shippedDate}</td>
            <td>{post.status}</td>
            <td>{post.comments}</td>
            <td>{post.customerNumber}</td>
            
        </tr>
        
         ))} 
    </table>
 
      </div>
    );
  }
}

export default Orders;

