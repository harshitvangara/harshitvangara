import React from "react"
import "./Employees.css"
class Employees extends React.Component {
  constructor(props) {
    super(props);
    this.state = { posts: [] };
    this.handledelte=this.handledelte.bind(this);
  }

  componentDidMount() {
    fetch("http://localhost:8000/employees/")
      .then(res => res.json())
      .then((result) => {
        this.setState({ posts: result });
        console.log(result)
      },
      (error)=>{
        console.log(error);
      })
  }
   handledelte(val){
    var entry=this.state.posts
    for(let i=0;i<entry.length;i++){
      if(entry[i].employeeNumber===val){
       entry.splice(i,1)
      }
    }
    this.setState({posts:entry})
  
  }
  render() {
    const array=[]
    const count=[]
    const add=[]
    for (let i=0;i<this.state.posts.length;i++){
       
       array.push({i})

       if (this.state.posts[i].jobTitle==="Sales Rep") {
        count.push({i}) 
         }
        else if(this.state.posts[i].jobTitle!=="President"&&this.state.posts[i].jobTitle!=="VP Sales"&&this.state.posts[i].jobTitle!=="VP Marketing") {
          add.push({i})
        }
      }


    return (
      
    
    <div className="float-child">
    <table border="1">
        <tr>
            <th>employeeNumber</th>
            <th>lastName</th>
            <th>firstName</th>
            <th>extension</th>
            <th>email</th>
            <th>officeCode</th>
            <th>reportsTo</th>
            <th>jobTitle</th>
            <th>Delete</th>
        </tr>
     
       { this.state.posts.map(post=>(
      
        <tr>
            <td>{post.employeeNumber}</td>
            <td>{post.lastName}</td>
            <td>{post.firstName}</td>
            <td>{post.extension}</td>
            <td>{post.email}</td>
            <td>{post.officeCode}</td>
            <td>{post.reportsTo}</td>
            <td>{post.jobTitle}</td>
            <td><button onClick={()=>this.handledelte(post.employeeNumber)}>delete</button></td>
        </tr>
        
         ))} 
    </table>
    <div>
    <table border="1">
      <h3>Summery</h3>
    <tr>
    <td>Employee Count</td>
    
    <td>Sales Representatives</td>
   
    <td>Sales Manager</td>
    
    </tr>
    <tr>
    <td>{array.length}</td>
    <td>{count.length}</td>
    <td>{add.length}</td>
    </tr>
    </table>
    </div>
 </div>

      
    );
  }
}

export default Employees;

