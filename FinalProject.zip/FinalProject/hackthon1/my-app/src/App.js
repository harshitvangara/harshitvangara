import {BrowserRouter ,Routes,Route} from 'react-router-dom';
import Layout from "./Layout"
import Display from "./Display"
import Employees from "./Employees"
import Orders from "./Orders"
export default function App() {
  return (
    //<Employees/>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route path="display" element={<Display/>} />  
          <Route path="employees" element={<Employees/>} /> 
          <Route path="orders" element={<Orders/>} />        
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
