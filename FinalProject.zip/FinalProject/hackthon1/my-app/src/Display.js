import React from "react"
class Display extends React.Component {
  constructor(props) {
    super(props);
    this.state = { posts: [] };
  }

  componentDidMount() {
    fetch("http://localhost:8000/offices/")
      .then(res => res.json())
      .then((result) => {
        this.setState({ posts: result });
      },
      (error)=>{
        console.log(error);
      })
  }

  render() {

    return (
      <div>
    

    <table border="1">
        <tr>
            <th>officeCode</th>
            <th>city</th>
            <th>addressLine1</th>
            <th>addressLine2</th>
            <th>state</th>
            <th>City</th>
            <th>postalCode</th>
            <th>territory</th>
        </tr>
     
       { this.state.posts.map(post=>(
      
        <tr>
            <td>{post.officeCode}</td>
            <td>{post.city}</td>
            <td>{post.addressLine1}</td>
            <td>{post.addressLine2}</td>
            <td>{post.state}</td>
            <td>{post.country}</td>
            <td>{post.postalCode}</td>
            <td>{post.territory}</td>
        </tr>
        
         ))} 
    </table>
 
      </div>
    );
  }
}

export default Display;

