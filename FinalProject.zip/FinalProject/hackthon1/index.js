var mysql = require('mysql');
const express=require('express');
const cors=require('cors')
const app=express()

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "classicmodels"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Database Connected");
});

app.use(cors());
app.get("/offices",(req,res)=>{
    con.query("select * from offices;",(err,results)=>{
        if(err) throw err;
        res.send(results);
    });

});

app.get("/employees",(req,res)=>{
    con.query("select * from employees;",(err,results)=>{
        if(err) throw err;
        res.send(results);
    });

});

app.get("/orders",(req,res)=>{
    con.query("select * from orders;",(err,results)=>{
        if(err) throw err;
        res.send(results);
    });

});

app.listen(port=8000, (err) => {
    if (err) throw err;
    console.log(`App listening on port ${port}!`)
  });