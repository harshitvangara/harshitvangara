function myfunction(){
    document.getElementById("myframe").src="Project1/index.html";
}
function  myfunction2()
{
    document.getElementById("myframe").src="Project1/index2.html";
}
function  myfunction3()
{
    document.getElementById("myframe").src="Project1/index3.html";
}
function  myfunction4()
{
    document.getElementById("myframe").src="Project1/index4.html";
}
function  myfunction5()
{
    document.getElementById("myframe").src="Project1/index5.html";
}
function  myfunction6()
{
    document.getElementById("myframe").src="Project1/index6.html";
}
function  myfunction7()
{
    document.getElementById("myframe").src="Project1/index7.html";
}
function  myfunction8()
{
    document.getElementById("myframe").src="Project1/index8.html";
}
function  myfunction9()
{
    document.getElementById("myframe").src="Project1/index9.html";
}
function  myfunction10()
{
    document.getElementById("myframe").src="Project1/index10.html";
}
function  myfunction11()
{
    document.getElementById("myframe").src="Project1/index11.html";
}
function  myfunction12()
{
    document.getElementById("myframe").src="Project1/index12.html";
}
function  myfunction21()
{
    document.getElementById("myframe").src="Project2/index1.html";
}
function  myfunction22()
{
    document.getElementById("myframe").src="Project2/index2.html";
}
function  myfunction23()
{
    document.getElementById("myframe").src="Project2/index3.html";
}
function  myfunction24()
{
    document.getElementById("myframe").src="Project2/index4.html";
}
function  myfunction31()
{
    document.getElementById("myframe").src="Project3/index.html";
}
function  myfunction32()
{
    document.getElementById("myframe").src="Project3/index2.html";
}
function  myfunction33()
{
    document.getElementById("myframe").src="Project3/index3.html";
}
function  myfunction34()
{
    document.getElementById("myframe").src="Project3/index4.html";
}
function  myfunction41()
{
    document.getElementById("myframe").src="Project4/index.html";
}
function  myfunction51()
{
    document.getElementById("myframe").src="Mini-Project/index.html";
}

