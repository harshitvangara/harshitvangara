var http = require('http');
var fs = require('fs');
const hostname = '127.0.0.1';
const port = 8000;
// Create a server object
const server = http.createServer(function (req, res) {
	
	
	var url = req.url;
	
	if(url ==='/about') {

        fs.readFile('about.html', function(err, data) {
            res.writeHead(200, {'Content-Type': 'text/html'});
            
		res.write(' Welcome to about us page');
		res.end(data);
        });
	}
	else if(url ==='/contact') {

        fs.readFile('../ex3/Responsive/index.html', function(err, data2) {
            res.writeHead(200, {'Content-Type': 'text/html'});
           
		res.write(' Welcome to contact us page');
		res.end(data2);
        });
	}
    else if(url ==='/home') {

        fs.readFile('home.html', function(err, data3) {
            res.writeHead(200, {'Content-Type': 'text/html'});
           
		res.write(' Welcome to home page');
		res.end(data3);
        });
	}
    
	else {
		res.write('Hello World!');
		res.end();
	}
});

server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
  });
