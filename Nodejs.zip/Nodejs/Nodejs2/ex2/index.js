const http = require('http');
const fs = require('fs');
const hostname = '127.0.0.1';
const port = 3000;



const server = http.createServer(function (req, res){ 
  fs.readFile('test.txt', 'utf-8', (err, file) => {
  if(err) console.log (err);
  const lines = file.toString().split('|');
  
  res.writeHead(200, {'Content-Type': 'text/html'});
  for(let i=0;i<lines.length-1;i=i+4){
  res.write(`<!DOCTYPE html>
  <html>
  <head>
  </head>
  <body>
  <table class="table" border="1" >
  <tr>
    <td  width="75px">`+lines[i]+`</td>
    <td  width="75px">`+lines[i+1]+`</td>
    <td  width="75px">`+lines[i+2]+`</td>
    <td  width="75px">`+lines[i+3]+`</td>
  </tr>
  </table>
  </body>
  </html>`);
  
  }
  res.end()
          
  });
});


server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});