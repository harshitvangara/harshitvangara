const express=require("express")
const app=express();
app.use(express.json());
var bodyparser = require('body-parser');
//var path = require('path');
let cors = require("cors");
app.use(cors());
app.use(bodyparser.json());
/*app.use(function(req,res,next){

    res.setHeader("Content-Type","application/json");
    res.setHeader("Access-Control-Allow-Origin","*");
    res.setHeader("Access-Control-Allow-Method","*");
    res.setHeader("Access-Control-Allow-Headers","*");
    return next();
});*/

app.use(express.json());
app.get('/user', function (req, res) {
   
    res.end(JSON.stringify(users));
});
app.post('/user',function(req,res){
    
    console.log(req.body);   
    console.log(req.params);
    console.log(req.query);
    users.push(req.body);
})
app.delete('/user:id',function(req,res){
    for(var i=0;i<users.length;i++)
    {
        if(req.params.id==users[i].id){
            users.splice(i,1);
            //console.log(req.params.id);
            //console.log(users[i].id);
        }
    }
})
app.put('/user:id',(req,res)=>{
    for(var i=0;i<users.length;i++){
        if(req.params.id==users[i].id){
            users[i].statusMessage=req.body.stat;
            //console.log(req.body.stat);
        }
    }
})
app.put('/presence/user:id',(req,res)=>{
    for(var i=0;i<users.length;i++){
        if(req.params.id==users[i].id){
            users[i].presence=parseInt(req.body.press);
            //console.log(req.body.press);
            //console.log(req.params)
        }
    
    }
})
let users = [{
    "id":1,
    "userID":"USR00001",
    "name":"Andrew Grudde",
    "profilePicture":"batman.jpg",
    "statusMessage" : "We become what we think about",
    "presence" : 1
},
{   "id":2,
    "userID":"USR00002",
    "name":"Steve Hughes",
    "profilePicture":"fight-club.jpg",
    "statusMessage":"A postive mindset brings positive things.",
    "presence" : 2
},
{   "id":3,
    "userID":"USR00003",
    "name" : "Kathy Smiley",
    "profilePicture":"forrest-gump.jpg",
    "statusMessage":"One small Positive thought can change your whole day",
    "presence":3
},
{    "id":4,
    "userID":"USR00004",
    "name":"Steve Dunk",
    "profilePicture":"spiderman.jpg",
    "statusMessage":"I am a rock star",
    "presence":4
},
{   "id":5,
    "userID":"USR00005",
    "name":"Maria Dropola",
    "profilePicture":"the-departed.jpg",
    "statusMessage":"I am using Gradious messenger",
    "presence":5
}
]
var server = app.listen(8080, function () {
    var host = server.address().address
    var port = server.address().port
    
    console.log(`Example app listening at http://localhost:${port}`)
 });