function fetchUsers() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
    anime(this.responseText);
    }
    };
    xhttp.open("GET", "http://localhost:8080/user", true);
    xhttp.send();
    }

//const obj = JSON.parse(animeCharacters);
function anime(users1){
 var users = JSON.parse(users1);
 let str ="";
 for(i=0;i<users.length;i++){
  str= str + "<div class='name'>"+users[i].name+"</div><div><img src="+users[i].profilePicture+" class='lorem"+users[i].presence+"'></img></div><div class='msg'>"+users[i].statusMessage+"</div>";
  
}

str="<div>"+str+"</div>";
document.getElementById("user").innerHTML=str;

}




function presence(){
    
    var x=document.getElementById("text1").value;
    var y=document.getElementById("text2").value;
    console.log(x);
    console.log(y);
    var xhttp = new XMLHttpRequest();
    xhttp.open("PUT", "http://localhost:8080/presence/user"+x, true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(JSON.stringify({"press":y}));
    fetchUsers();
}

function status(){
    var x1=document.getElementById("text3").value;
    var y1=document.getElementById("text4").value;    
    var xhttp = new XMLHttpRequest();
    xhttp.open("PUT", "http://localhost:8080/user"+x1, true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(JSON.stringify({"stat":y1}));
    fetchUsers();
}

function newuser(){
    temp={};
    temp.name=document.getElementById("text5").value;
    temp.presence=document.getElementById("text71").value;
    temp.userID=document.getElementById("text71").value;
    temp.statusMessage=document.getElementById("text6").value;
    temp.profilePicture=document.getElementById("text8").value;

    temp={
        "id": parseInt(temp.userID),
        "userID":"USR0000"+temp.userID,
        "name":temp.name,
        "profilePicture":temp.profilePicture,
        "statusMessage":temp.statusMessage,
        "presence":parseInt(temp.presence)
    }
    
    var xhttp = new XMLHttpRequest();
    xhttp.open("POST", "http://localhost:8080/user", true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(JSON.stringify(temp));
    fetchUsers();
}

function dltusr(){
    var del = document.getElementById("text9").value;
    var xhttp = new XMLHttpRequest();
    xhttp.open("DELETE", "http://localhost:8080/user"+del, true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send();
    fetchUsers();
}