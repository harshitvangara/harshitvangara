var user = {
  "firstname":"will" ,
  "lastname": "smith",
  "age": 33,
  "department" : "Film",
  "isMale": true,
  "marks":[44,92,53,45,76],
  "address":{
      "permanent":{
          "flatNumber" : 21,
          "blockNumber": "B",
          "streetName":"Sardar Street",
          "city":"Hyderabad",
          "pincode":"500010"
      },
      "temporary":{
          "flatNumber" : 21,
          "blockNumber": "B",
          "streetName":"Sardar Street ",
          "city":"Hyderabad",
          "pincode":"500010"
      },
  },

  "dateofRegister" : new Date(),
  "getFullName" : function(){
      return firstname+""+lastname;
  },
  "weight":null,
  "eyeColor":undefined
};
var keys=Object.keys(user);
var values = Object.values(user);
for(i=0;i<keys.length;i++){
console.log(keys[i] +":"+typeof values[i]);
}


