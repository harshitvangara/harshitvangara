const express = require('express');
const app = express();
const fs = require('fs');
const bodyparser = require('body-parser')

const path = require('path');
var cors =require('cors');
app.use(cors());
  

var data = {
      Health :  35,
      Finance :  20,
      Carreer :  18,
      Education :  15,
      Family :  5,
      Business :  7
}
  
app.get('/user' , (req,res)=>{
   
   res.end(JSON.stringify(data));
})
  
// Server setup
app.listen(4000 , ()=>{
    console.log("server running");
});