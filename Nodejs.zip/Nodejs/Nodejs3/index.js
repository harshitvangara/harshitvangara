
var users={"firstname":"will",
           "lastname":"smith",
           "Age":33,
           "Department":"film"
}
  var keys=Object.keys(users);
  
  for (let i = 0; i < keys.length; i++) {
      console.log(keys[i]);
   
  }
  



