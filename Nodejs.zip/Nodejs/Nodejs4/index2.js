const express =require("express");
const app=express();
const fs = require('fs');
const bodyparser = require('body-parser');
app.use(bodyparser.urlencoded({extended:true}))
app.use('/',function(req,res,next){

    res.setHeader("Content-Type","application/x-www-form-urlencoded");
    res.setHeader("Access-Control-Allow-Origin","*");
    res.setHeader("Access-Control-Allow-Method","*");
    res.setHeader("Access-Control-Allow-Headers","*");
    return next();
});
app.post('/user',(req,res)=>{
    var folder=req.body.user;
    console.log(folder)
    var str="";
    fs.readdir(folder, (err, files) => {
        files.forEach(file => {
        //console.log(file);
        str=str+file+"|";
        console.log(str)
        });
 var joint=str.split("|");
 console.log(joint)
 res.send(JSON.stringify(joint));
});
});


app.listen(8080,()=>{
    console.log("Server is started at 8080");
})