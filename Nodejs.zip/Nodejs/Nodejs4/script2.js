var direct="/home";
var direct2=direct;
function jyper(user){
    var xhttp = new XMLHttpRequest();
    var name="user="+user;
    console.log(name)
    xhttp.open("POST", "http://localhost:8080/user", true);
    xhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    xhttp.send(name);
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
    //console.log(this.responseText);
        keka(this.responseText);
         }
};
}
function keka(joint)
{
    //console.log(joint)
joint=JSON.parse(joint);
//console.log(joint)
var demo ="<tr><th>Harshit PC</th></tr>";
for(i=0;i<joint.length-1;i++)
{
    demo=demo+"<tr>";
    demo=demo+"<td><img src=\""+folder_icon(joint[i])+"\" height=\"20\" width=\"20\"><button onclick='gig(\""+joint[i]+"\")'>"+joint[i]+"</button></td>";
    
    demo=demo+"</tr>";
}
document.getElementById('table1').innerHTML=demo;
}

function gig(figure)
{
direct=direct+"/"+figure;
jyper(direct);

}
function backof(){
    let adress=direct.lastIndexOf("/");
    direct=direct.substring(0,adress);
    console.log(direct);
    jyper(direct);
}
function reload(){
  direct=direct2;
  jyper(direct);
}
function folder_icon(file) {
    if (file.includes(".css")) {
       return "css.png";
    }
    if (file.includes(".txt")) {
       return "text.jpg";
   }
   if (file.includes(".svg")) {
       return "svg.png";
   }
    if (file.includes(".csv")) {
       return "csv.jpg";
   }
   if (file.includes(".pdf")) {
       return "pdf.jpg";
   }
   if (file.includes(".jpg")) {
       return "img.jpg";
   }
   if (file.includes(".jpeg")) {
       return "img.jpg";
   }
   if (file.includes(".png")) {
       return "img.jpg";
   }
   if (file.includes(".webp")) {
     return "img.jpg";
 }
   if (file.includes(".js")) {
       return "js.png";
   }
   if (file.includes(".html")) {
       return "html.png";
   }
   if (file.includes(".xlsx")) {
       return "xlsx.png";
   }
   if (file.includes(".rar")) {
       return "rar.png";
   }
   if (file.includes(".zip")) {
       return "zip.png";
   }
   return "folder.png"
}