function fetchUsers() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
       // console.log(this.responseText)
    anime(this.responseText);
    }
    };
    xhttp.open("GET", "http://localhost:8080/user", true);
    xhttp.send();
}
function anime(funload)
{
    var funload1=JSON.parse(funload);
    console.log(funload1);
    var str = ''
    for(i=0;i<funload1.length;i++){
       console.log(funload1[i]);
       exe=funload1[i].split(".").pop();
       console.log(exe);
       switch(exe)
       {
           case "html":
               str=str+" <i class='fab fa-html5'>"+funload1[i]+"</i>";
               console.log(exe);
               break;
           case "css":
                str=str+" <i class='fab fa-html5'>"+funload1[i]+"</i>";
                console.log(exe);
                break;
           case "js":
                str=str+" <i class='fab fa-html5'>"+funload1[i]+"</i>";
                console.log(exe);
                break;   
           case "txt":
                str=str+" <i class='fab fa-html5'>"+funload1[i]+"</i>";
                console.log(exe);
                break;         
           default:
                str=str+"folder"
                break;

       }
      
    }
    console.log(str);
    document.getElementById("tree").innerHTML=str;
}
