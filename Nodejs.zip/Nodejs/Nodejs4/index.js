
const testfolder='./Documents';
const express =require("express");
app=express();
const fs = require('fs');
app.use(express.json());
var bodyparser = require('body-parser');
//var path = require('path');

app.use(bodyparser.json());
app.use(function(req,res,next){

    res.setHeader("Content-Type","application/json");
    res.setHeader("Access-Control-Allow-Origin","*");
    res.setHeader("Access-Control-Allow-Method","*");
    res.setHeader("Access-Control-Allow-Headers","*");
    return next();
});

// Function to get current filenames
// in directory
fs.readdir(testfolder, (err, files) => {
if (err)
	console.log(err);
else {
	console.log("\nCurrent directory filenames:");
	files.forEach(file => {
	console.log(file);
    
	})
}
app.get('/user', (req,res)=>{
   
    res.end(JSON.stringify(files));
 })
})


app.listen(8080);
