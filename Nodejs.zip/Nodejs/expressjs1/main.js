const express=require("express");
const app=express();
const start1=require("./main1");
const start2=require("./main2");
const start3=require("./main3")
app.get("/start/:id",(req,res)=>{
    let num=start1.start(req.params.id);
    console.log(req.params.id)
    res.end(num);

});
app.get("/start1/:id",(req,res)=>{
    let num1=start2.start1(req.params.id);
    console.log(req.params.id)
    res.end(num1);

});
app.get("/start2/:id",(req,res)=>{
    let num2=start3.start2(req.params.id)
    res.end(num2)
})
app.get("/start3/:id",(req,res)=>{
    let num3=start3.start3(req.params.id)
    res.end(num3)
});
app.get("/start4/:id",(req,res)=>{
    let num4=start2.start4(req.params.id)
    res.end(num4)
})
app.listen(8080, () => {
    console.log(`Server is running at http://localhost:8080/`);
  });