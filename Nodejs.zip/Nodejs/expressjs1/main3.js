var start2=function(userInput){
    const fahrenheit = (userInput*1.8)+32;
    return `${fahrenheit}`

       
  }

var start3=function(userInput){
    const fahrenheit = (userInput-32)/1.8;
    return `${fahrenheit}`

       
  }

  module.exports={start2,start3}