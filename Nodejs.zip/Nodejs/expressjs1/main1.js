var start= function(userInput){
    let isprime=true;
    for (i=2;i<userInput;i++){
    if(userInput%i==0)
    {
     isprime=false;
     break;	
    }
    }
    if(isprime)
    return "PrimeNumber"
    else
    return "Not prime number"  
    }

 module.exports={start}