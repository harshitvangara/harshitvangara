var start1=function(userInput){
    const factor=0.621371;
    const miles =userInput * factor;
    
    return `${miles}`

}

var start4=function(userInput){
    const factor=0.621371;
    const miles =userInput /factor;
    
    return `${miles}`

}


module.exports={start1,start4}