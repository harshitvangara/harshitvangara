var node = process.env.PATH;

console.log(node);