const fs = require("fs")
const path = require("path")

const currentPath = path.join(__dirname, "myfile1.txt")
const newPath = path.join( "C:/Users/DELL/Downloads/ex3", "exercise1.txt")

fs.rename(currentPath, newPath, function(err) {
  if (err) {
    throw err
  } else {
    console.log("Successfully moved the file!")
  }
})