// Requiring module
const reader = require('xlsx')

// Reading our test file
const file = reader.readFile('text.xlsx')

// Sample data set
let student_data = [{"name":"Anand", "age":22, "gender":0, "city":"Mumbai"}, {"name":"Bihu", "age":17, "gender":1, "city":"Pune"}]

const ws = reader.utils.json_to_sheet(student_data)

reader.utils.book_append_sheet(file,ws,"Sheet2")

// Writing to our file
reader.writeFile(file,'text.xlsx')
