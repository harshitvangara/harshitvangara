
const users = [
        { name: "Krish", 
         age: 32, 
         gender: "Male",
         city:"Chennai" 
        },
        { name: "Maha",  
        age: 35, 
        gender: "Female" ,
        city:"Mumbai"
        },
        { name: "Ritha",  
        age: 25, 
        gender: "Female" ,
        city:"Delhi"
    } ]

    const fs = require('fs');

    var newJ ='';
    fs.appendFileSync('jsonset.txt','name | age | gender | city \n');
    var l=users.length;

    for(let i=0;i<l;i++){
    
       newJ =  users[i].name+ ' | ' +users[i].age+ ' | ' +users[i].gender+ ' | ' +users[i].city;
       fs.appendFile("jsonset.txt" , newJ + "\n",function (err) {
            if (err) {
                console.log('error'+err);   }

      });       
    }
    console.log('Mission Successfull');
