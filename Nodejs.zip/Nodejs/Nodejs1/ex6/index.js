const fs = require("fs")
  fs.readFile('file.txt', 'utf-8', (err, file) => {
      if(err) throw err;
    const lines = file.split('\n')
    var fbrk="";
    for (let line of lines)
    {
      fbrk+=line+'\n';
    }  
    require('fs').writeFile('file.txt',fbrk,(err,data) => {
        if(err){
            console.error(err);
            return;
        }
        //file written successfully
    });
    console.log(fbrk);
            
});



