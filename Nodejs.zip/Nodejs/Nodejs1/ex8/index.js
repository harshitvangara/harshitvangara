const fs= require('fs')
var json=[]
let user={"name":"","age":"","gender":"","city":""}
fs.readFile('myfile.txt', 'utf-8', (err, file) => {
    if(err) throw err;
  const lines = file.split('|')
  user.name=lines[0];
  user.age=lines[1];
  user.gender=lines[2];
  user.city=lines[3];
 json.push(user);
 var myobj=JSON.stringify(json)
  console.log(myobj)
          
});