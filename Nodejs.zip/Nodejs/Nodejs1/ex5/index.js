const fs = require("fs")
var count=0;
fs.readFile('C:/Users/DELL/Downloads/ex3/myfile.txt','utf-8', function (err, data) {
    if (err) throw err;
    const lines = data.split('\n');
    for (let line of lines){
        count++;
    if(line.includes('Lorem')){
    
     
     console.log(count);
    }
}
  });