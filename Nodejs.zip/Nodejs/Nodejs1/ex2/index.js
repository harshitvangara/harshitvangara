var words="";
for(var i=0;i<100;i++){
const result = Math.random().toString(36).substring(2,12);
//console.log(result);
words+=result+'\n';
}

require('fs').writeFile('C:/Users/DELL/Downloads/ex2/random-words.txt',words,(err,data) => {
    if(err){
        console.error(err);
        return;
    }
    //file written successfully
});
console.log(words);