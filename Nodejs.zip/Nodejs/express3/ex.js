// Has the business improved week after week
const express=require("express");
const app=express();
const order=require("./order.json");
const moment = require('moment');
var joint=""
var temp={
    week:"",
    amount:""
};
var weekAmount=[];
var map4=new Map()
var temp1=0;
for(let i=0; i < order.length; i++){
    if (order[i].OrderDate.includes("2022")) {
        weeknumber = moment(order[i].OrderDate, "DD-MM-YYYY").week();
        let a = Object.create(temp);
        a.week = weeknumber;
        a.amount = parseInt(order[i].OrderAmount);
        weekAmount.push(a)
    }
}
console.log(weekAmount);
for (let i = 0; i < weekAmount.length; i++) {
    var sum3 = 0;
    for (let j = 0; j < weekAmount.length; j++) {
        if (Object.values(weekAmount)[i].week == Object.values(weekAmount)[j].week) {
            sum3 = sum3 + Object.values(weekAmount)[j].amount;
        }
    }
    map4.set(Object.values(weekAmount)[i].week, sum3)
}
console.log(map4);
var map3 = new Map([...map4].sort((a, b) => a[0] - b[0]));
for (const [key, value] of map3) {
    if (value > temp1) {
        joint=joint+"In 2022 Week " + key + " value is " + value+" Business is Improved<br>";
    } else {
        joint=joint+"In 2022 Week " + key + " value is " + value+" Business is Not improved<br>";
    }
    temp1 = value;
}
for(let i=0; i < order.length; i++){
    if (order[i].OrderDate.includes("2021")) {
        weeknumber = moment(order[i].OrderDate, "DD-MM-YYYY").week();
        let a = Object.create(temp);
        a.week = weeknumber;
        a.amount = parseInt(order[i].OrderAmount);
        weekAmount.push(a)
    }
}
console.log(weekAmount);
for (let i = 0; i < weekAmount.length; i++) {
    var sum3 = 0;
    for (let j = 0; j < weekAmount.length; j++) {
        if (Object.values(weekAmount)[i].week == Object.values(weekAmount)[j].week) {
            sum3 = sum3 + Object.values(weekAmount)[j].amount;
        }
    }
    map4.set(Object.values(weekAmount)[i].week, sum3)
}
console.log(map4);
var map3 = new Map([...map4].sort((a, b) => a[0] - b[0]));
for (const [key, value] of map3) {
    if (value > temp1) {
        joint=joint+"In 2021 Week " + key + " value is " + value+" Business is Improved<br>";
    } else {
        joint=joint+"In 2021 Week " + key + " value is " + value+" Business is Not improved<br>";
    }
    temp1 = value;
}
app.get('/user',(req,res)=>{
    res.send(joint);
});
app.listen(8080,()=>{
    console.log("Server is started at 8080");
})



