var address=require("./address.json")
var order=require("./order.json")
const express=require("express");
const app=express();

var unique_custID=[];
for(i in order){
    if(unique_custID.includes(order[i].Customer_ID)){
        continue;
    }
    else{
    unique_custID.push(order[i].Customer_ID);
    }
}
console.log(unique_custID);

var unique_cust_details=[];

for(i in unique_custID){
    var sum=0;
    for(j in order){
        if(unique_custID[i]==order[j].Customer_ID){
            sum+= parseInt(order[j].OrderAmount);
        }
    }
    for(k in address){
        if(unique_custID[i]==address[k].Customer_ID){
            city=address[k].City;
            break;
        }
    }
    unique_cust_details.push({"customerID":unique_custID[i],"Total Amount":sum,"City":city})

}
app.get('/user',(req,res)=>{
    res.send(unique_cust_details);
});
app.listen(8080,()=>{
    console.log("Server is started at 8080");
})
//console.log(unique_cust_details);