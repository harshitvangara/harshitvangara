var dt=new Date();
console.log(dt.getTime());
var dt1=new Date("2022-04-10");
console.log(dt1.getTime())
var dt2=new Date("2022-04-09");
console.log(dt1.getTime()-dt2.getTime())
console.log(24*60*60*1000)
var dt3 =new Date("1970-01-01")
console.log(dt3.getTime())