var Loan=require("./loan.js")
/*const express =require("express")
const app=express()
const bodyparser=require('body-parser')
app.use(bodyparser.urlencoded({extended:true}));
app.use(bodyparser.json());*/
var carLoan=function(amount){
    Loan.Loan.call(this,amount);
}

carLoan.prototype.handleNonpayement=function(){
    return "take car back"
}
require("util").inherits(carLoan,Loan.Loan)

    var p1=new carLoan(500);
    var str=p1.getLoanAmount();
    var str2=p1.runCreditcheck();
    console.log(str);
    console.log(str2);

module.exports={carLoan}