var Loan=require("./loan");


var personal=function(amout){
    Loan.Loan.call(this,amout)
}

require("util").inherits(personal,Loan.Loan)
var p1=new personal(60)
var str=p1.getLoanAmount();
var str2=p1.handleNonpayment()
console.log(str);
console.log(str2);