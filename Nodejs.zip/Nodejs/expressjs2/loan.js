var Loan=function(amnt){
    this.amount=amnt;
}
Loan.prototype.getLoanAmount=function(){
    
    return `${this.amount}`;
}
Loan.prototype.runCreditcheck=function(){
  return "your credit score is 600"
}
Loan.prototype.sendReminder=function(){
  return "your have to pay 700"
}
Loan.prototype.handleNonpayment=function(){
 return "you are not eligible"
}

module.exports={Loan}