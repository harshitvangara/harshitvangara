var card=function(amnt){
    this.amount=amnt;
}
card.prototype.getamount=function(){
    
    return `${this.amount}`;
}
card.prototype.cardnumber=function(){
  return "your card number 60003992"
}
card.prototype.balanceempty=function(){
  return "your card balance is empty"
}

module.exports={card}