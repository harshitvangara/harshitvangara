var card=require("./card.js")
/*const express =require("express")
const app=express()
const bodyparser=require('body-parser')
app.use(bodyparser.urlencoded({extended:true}));
app.use(bodyparser.json());*/
var credit=function(amount){
    card.card.call(this,amount);
}

card.prototype.cardreturn=function(){
    return "taking card back"
}
require("util").inherits(credit,card.card)

    var p1=new card(500);
    var str=p1.getamount();
    var str2=p1.cardnumber();
    console.log(str);
    console.log(str2);

module.exports={card}