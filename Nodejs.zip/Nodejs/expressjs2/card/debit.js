var card=require("./card.js");
var credit=require("./credit")

var debit=function(amout){
    card.card.call(this,amout)
}

require("util").inherits(debit,card.card)
require("util").inherits(debit,credit.cardreturn)
var p1=new debit(60)
var str=p1.getamount();
var str2=p1.cardreturn()
console.log(str);
console.log(str2);