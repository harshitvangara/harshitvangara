//Primitive ,Arrays and Any
var num1 = 100;
var num2 = 200;
var color = "blue";
var isDone = false;
var list = [1, 2, 3];
var str = ['john', 'jane'];
var obj = { x: 0 };
obj.bar = 100;
obj.str = "hello";
console.log(str);
console.log(color);
console.log(num1 + num2);
console.log(isDone);
console.log(list);
console.log(obj);
