//Generics
function identity<Type>(arg:Type):Type{
    return arg;
}

var out=identity<String>("Hello World");
console.log(out);