//interfaces
interface OS {  
    name: String;  
    language: String;  
}  
var OperatingSystem = (type: OS): void => {  
  console.log('Android ' + type.name + ' has ' + type.language + ' language.');  
};  
var Oreo = {name: 'O', language: 'Java'}  
OperatingSystem(Oreo);  