var myAdd = function (x, y) {
    return x + y;
};
console.log(myAdd(5, 3));
