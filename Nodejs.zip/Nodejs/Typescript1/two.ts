//functions
var myAdd = function (x: number, y: number) : number {  
    return x + y;  
}; 
console.log(myAdd(5,3)); 