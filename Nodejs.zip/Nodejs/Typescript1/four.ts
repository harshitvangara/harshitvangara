//union types
function printId(id: number | string) {
    console.log("Your ID is: " + id);
  }
  
  printId(101);

  printId("202");