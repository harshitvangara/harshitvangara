//Primitive ,Arrays and Any
var num1:number=100;
var num2:number=200;
var color:string="blue";
var isDone:boolean=false;
var list:number[]=[1,2,3];
var str:string[]=['john','jane'];
var obj:any={x:0}; 
obj.bar=100;
obj.str="hello"
console.log(str);
console.log(color);
console.log(num1+num2);
console.log(isDone);
console.log(list);
console.log(obj);