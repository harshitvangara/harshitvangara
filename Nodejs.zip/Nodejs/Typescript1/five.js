function identity(arg) {
    return arg;
}
var out = identity("Hello World");
console.log(out);
