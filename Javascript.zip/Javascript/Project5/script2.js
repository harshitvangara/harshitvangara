function validate(){
    var user = document.getElementById("name").value;
   
    var user2 = document.getElementById("name");
    
    var re = /^[A-Za-z]+$/;
    if (re.test(user)) {
        
        return true;
    }
    else {
        user2.style.border = "red solid 3px";
        
        return false;

    }
    
    
}

function validate2(){
    var usr = document.getElementById("lname").value;
    var usr2 = document.getElementById("lname");
    var re = /^[A-Za-z]+$/;
    if (re.test(usr)) {
        
        return true;
    }
    else {
        usr2.style.border = "red solid 3px";
        
        return false;
    }
}

function validate3(){
    var email = document.getElementById("exampleInputEmail1").value;
    var email2 = document.getElementById("exampleInputEmail1");
   var re = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
   if (re.test(email)) {
    
    return true;
}
else {
    email2.style.border = "red solid 3px";
    return false;
}
}
function validate4(){
    var num = document.getElementById("number").value;
    var num2 = document.getElementById("number");
   var re = /^[0-9]{10}$/;
   if (re.test(num)) {
    
    return true;
}
else {
    num2.style.border = "red solid 3px";
    return false;
}
}

  function validate5(){
    var num = document.getElementById("Customization").value;
    var num2 = document.getElementById("Customization");
   var re = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/;
   if (re.test(num)) {

    return true;
}
else {
    num2.style.border = "red solid 3px";
    return false;
}
}
function checkName(){
    var x =document.getElementById("name");
    if(x.value =="")
    {
        alert(" first Name cannot be empty");
        x.focus();   
    }
    var x =document.getElementById("lname");
    if(x.value =="")
    {
        alert("Last Name cannot be empty");
        x.focus();   
    }
    var y =document.getElementById("exampleInputEmail1");
    if(y.value =="")
    {
        alert("Email cannot be empty");
        y.focus();   
    }
    var z =document.getElementById("number");
    if(z.value =="")
    {
        alert("Phone number cannot be empty");
        z.focus();  
    }
    var num2 = document.getElementById("Customization");
    if(num2.value =="")
    {
        alert("Date of Birth cannot be empty");
        num2.focus();  
    }
}
