let users = [{
    "userID":"USR00001",
    "name":"Andrew Grudde",
    "profilePicture":"batman.jpg",
    "statusMessage" : "We become what we think about",
    "presence" : 1
},
{
    "userID":"USR00002",
    "name":"Steve Hughes",
    "profilePicture":"fight-club.jpg",
    "statusMessage":"A postive mindset brings positive things.",
    "presence" : 2
},
{
    "userID":"USR00003",
    "name" : "Kathy Smiley",
    "profilePicture":"forrest-gump.jpg",
    "statusMessage":"One small Positive thought can change your whole day",
    "presence":3
},
{
    "userID":"USR00004",
    "name":"Steve Dunk",
    "profilePicture":"spiderman.jpg",
    "statusMessage":"I am a rock star",
    "presence":4
},
{
    "userID":"USR00005",
    "name":"Maria Dropola",
    "profilePicture":"the-departed.jpg",
    "statusMessage":"I am using Gradious messenger",
    "presence":5
}
]
//const obj = JSON.parse(animeCharacters);
function anime(){
 let str ="";
 for(i=0;i<users.length;i++){
  str= str + "<div class='name'>"+users[i].name+"</div><div><img src="+users[i].profilePicture+" class='lorem"+users[i].presence+"'></img></div><div class='msg'>"+users[i].statusMessage+"</div>";
  
}

str="<div>"+str+"</div>";
document.getElementById("user").innerHTML=str;

}
let temp=[{
    "userID":"",
    "name":"",
    "profilePicture":"",
    "statusMessage":"",
    "presence":""
},
]



function presence(){
    
    var x=document.getElementById("text1").value;
    var y=document.getElementById("text2").value;
    console.log(x);
    console.log(y);
    users[x-1].presence=y;
    anime();
}

function status(){
    var x1=document.getElementById("text3").value;
    var y1=document.getElementById("text4").value;
    users[x1-1].statusMessage=y1;
    anime();
}

function newuser(){
    var indx = 0;
    indx = users.length;
    indx++;
    var givId = "USR0000"+indx;
    console.log(givId);
    temp.name=document.getElementById("text5").value;
    temp.presence=document.getElementById("text7").value;
    temp.userId=givId;
    temp.statusMessage=document.getElementById("text6").value;
    temp.profilePicture=document.getElementById("text8").value;
    users.push(temp);
    anime();
}

function dltusr(){
    var del = document.getElementById("text9").value;

	for (var i = 0; i < users.length; i++) {
		if(del == i+1)
		{
			users.splice(i, 1); 
		}
	}
 anime();
}