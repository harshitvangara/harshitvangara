function fetchUsers() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
    //console.log(this.responseText);
        loadUsers(this.responseText);
    }
    };
    xhttp.open("GET", "https://6254326d89f28cf72b59c5eb.mockapi.io/addusers", true);
    xhttp.send();
    }
 var ide;
 var myobj ={"userId":"","userName":"","age":"","state":""};

 function editUser(id,name,age,city)
 {
     ide=id;
     
     document.getElementById("text5").value=name;
     document.getElementById("text6").value=city;
     document.getElementById("text8").value=age;


 }
    function loadUsers(userinfo){
        var userinfo2=JSON.parse(userinfo);
        var str="";
        //console.log(userinfo2);
        for(i=0;i<userinfo2.length;i++)
        {
            str= str+"<tr><th scope='row'>"+userinfo2[i].userId+"</th><td>"+userinfo2[i].age+"</td><td>"+userinfo2[i].userName+"</td><td>"+userinfo2[i].state+"</td><td><button data-toggle='modal' data-target='#myModal' onclick='editUser("+userinfo2[i].id+",\""+userinfo2[i].userName+"\",\""+userinfo2[i].age+"\",\""+userinfo2[i].state+"\")'class='btn btn-success btn-sm rounded-0' type='button' title='Edit'>edit</button><button onclick='deleteUser("+userinfo2[i].id+")'class='btn btn-danger btn-sm rounded-0' type='button' data-toggle='tooltip' data-placement='top' title='Delete'>delete</button></td></tr>"
        }
        //console.log(str)
        document.getElementById("demo2").innerHTML=str;
    }
    
    function addUser() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        
    document.getElementById("demo").innerHTML = this.responseText;
    }
    };
    var myobj ={"userId":"","userName":"","age":"","state":""};
    index=document.getElementById("text1").value;
    myobj.userId="USR00"+index;
    myobj.userName=document.getElementById("text3").value;
    myobj.state=document.getElementById("text4").value;
    myobj.age=document.getElementById("text2").value;
    xhttp.open("POST", "https://6254326d89f28cf72b59c5eb.mockapi.io/addusers", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(myobj));
    }

    function updateUser() {
    index=document.getElementById("text7").value;
    myobj.userId="USR00"+ide;
    myobj.userName=document.getElementById("text5").value;
    myobj.state=document.getElementById("text6").value;
    myobj.age=document.getElementById("text8").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
    //document.getElementById("demo").innerHTML = this.responseText;
    
    }
    };
    link="https://6254326d89f28cf72b59c5eb.mockapi.io/addusers/"+ide;
    xhttp.open("PUT",link, true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(myobj));
    }
    


    function deleteUser(id) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
    fetchUsers();
    //document.getElementById("demo").innerHTML = this.responseText;
    }
    };
    
    link="https://6254326d89f28cf72b59c5eb.mockapi.io/addusers/"+id;
    xhttp.open("DELETE", link, true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send();
    }
   
    
    function validate(){
        var user = document.getElementById("text3").value;
        var user2= document.getElementById("text3")
        
        
        var re = /^[A-Za-z]+$/;
        if (re.test(user)) {
            
            return true;
        }
        else {
            alert("Enter in Aplhabests only");
            
            return false;
    
        }
        
        
    }

    function validate2(){
       
        var user21 = document.getElementById("text4").value;
        var user22 = document.getElementById("text4")
        
        var re = /^[A-Za-z]+$/;
        if (re.test(user21)) {
            
            return true;
        }
        else {
            alert("Enter in Aplhabests only");
            
            return false;
    
        }
        
        
    }
    function validate3(){
        var user = document.getElementById("text5").value;
        var user2= document.getElementById("text5")
        
        
        var re = /^[A-Za-z]+$/;
        if (re.test(user)) {
            
            return true;
        }
        else {
            alert("Enter in Aplhabests only");
            
            return false;
    
        }
        
        
    }

    function validate4(){
       
        var user21 = document.getElementById("text6").value;
        var user22 = document.getElementById("text6")
        
        var re = /^[A-Za-z]+$/;
        if (re.test(user21)) {
            
            return true;
        }
        else {
            alert("Enter in Aplhabests only");
            
            return false;
               
        }
        
    }