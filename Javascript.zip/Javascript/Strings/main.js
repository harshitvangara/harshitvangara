

function concat(){
   
    
        arr1=["harshit","vangara","paper"];
        arr2=["lenovo","samsung"];
        for(i=0;i<arr2.length;i++)
        {
            j=arr1.length;
            arr1[j]=arr2[i];
            j++;
        
        }
        console.log(arr1);
        document.getElementById("demo1").innerHTML=arr1;
    
    
}

function indexof(){
    arr1=["harshit","vangara","paper"];
    
    ar = ["harshit"];

    for(i=0;i<arr1.length;i++)
    {
        if(arr1[i]===ar[0]){
            console.log(i);
            document.getElementById("demo2").innerHTML=i;
        }
    }
    return -1
}

function join(){
    arr1=["harshit","vangara","paper","lenovo"];
    var arr3="";
    

    for(i=0;i<arr1.length;i++)
    {
        arr3+=arr1[i];
    }
    console.log(arr3);
   document.getElementById("demo3").innerHTML=arr3;
}

function lastindex(){
    arr1=["harshit","vangara","paper","lenovo"];
    ar2="lenovo";
    for(index=arr1.length-1;index>=0;index--){
        if(arr1[index]===ar2)
        {
         console.log(index);
         document.getElementById("demo4").innerHTML=index;
        }
    }
    return -1
}

function push(){
    arr1=["harshit","vangara","paper","lenovo"];
    ar3="marriage"
    i=arr1.length;
    arr1[i]=ar3;
    console.log(arr1);
    console.log(arr1.length);
    document.getElementById("demo5").innerHTML=arr1;

}

function remove(){
    var arrr=["harshit","vangara","paper","lenovo"];

    arrr=arrr.slice(-1)[0]
    
    console.log(arrr);
   document.getElementById("demo6").innerHTML=arrr;
}
function shift(){
    var array=["harshit","vangara","paper","lenovo"];
    array1=array.slice(0,1)[0];
    console.log(array1);
    document.getElementById("demo7").innerHTML=array1;
}

function unshift(){
    var array2=["vangara","paper","lenovo"];
    for(i=array2.length;i>=0;i--)
    {
        array2[i]=array2[i-1];
    }
   array2[0]="harshit";
    console.log(array2);
    console.log(array2.length);
    document.getElementById("demo8").innerHTML=array2;
    
}

function sort() {
    var array = [12, 10, 15, 11, 14, 13, 16];
    var done = false;
    while (!done) {
      done = true;
      for (var i = 1; i < array.length; i += 1) {
        if (array[i - 1] > array[i]) {
          done = false;
          var tmp = array[i - 1];
          array[i - 1] = array[i];
          array[i] = tmp;
        }
      }
    }
  
    console.log(array);
    document.getElementById("demo9").innerHTML=array;
  }
  
  